"""Patient portal authentication module."""
